sap.ui.define([], function() {
	"use strict";

	return {
		genderFullform: function(sValue) {
			if (sValue === "M") {
				sValue = "Male";
			} else if (sValue === "F") {
				sValue = "Female";
			}
			return sValue;
		}
	};

});