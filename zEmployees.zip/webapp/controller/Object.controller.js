var that;
sap.ui.define([
	"zemployees/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"zemployees/model/formatter"
], function(
	BaseController,
	JSONModel,
	History,
	formatter
) {
	"use strict";

	return BaseController.extend("zemployees.controller.Object", {

		formatter: formatter,

		onInit: function() {
			that=this;
			if(!this.oDialog)
		{
			this.oDialog=sap.ui.xmlfragment("zemployees.fragments.userInfo",this);
			this.getView().addDependent(this.oDialog);
		}
			var createHistoryModel=new JSONModel();
			createHistoryModel.setData({
				"CompanyName":"",
				"FromDate":"",
				"ToDate":"",
				"Designation":"",
				"Reason":""
			});
			this.getView().setModel(createHistoryModel,'createHistoryModel');
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function(oEvent) {
			
				
				var ZEMP_ID = this.getModel("EmpDetail").getProperty("/EmpId");
				this.getView().getModel().read("/EMPLOYEESet("+ZEMP_ID+")",{
					urlParameters:{
						"$expand":"EmpDetailsTO_WrkHistory"
					},
					success:function(OData,response){
						that.getView().getModel("EmpDeatil").setData(OData);
					},
					Error:function(response){
						
					}
					
				});
		
		},
			addNewHistory:function(oEvent)
		{
			this.oDialog.open();
		},
		onclosePressed:function(oEvent)
		{
			this.oDialog.close();
		},
	
	});

});