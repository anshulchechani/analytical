
sap.ui.define([
	"zemployee/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"zemployee/model/formatter"
], function(
	BaseController,
	JSONModel,
	History,
	formatter
) {
	"use strict";

	return BaseController.extend("zemployee.controller.Object", {

		formatter: formatter,
		onInit: function() {
			if(!this.oDialog)
				{
					this.oDialog=sap.ui.xmlfragment("zemployees.fragments.userInfo",this);
					this.getView().addDependent(this.oDialog);
				}
					this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
				},
		
				_onObjectMatched: function(oEvent) {
				var oModel=sap.ui.getCore().getModel("dataModel");
				this.byId("inpFirstName").setValue(oModel.oData.FirstName);
				this.byId("inpLastName").setValue(oModel.oData.LastName);
				this.byId("inpEmail").setValue(oModel.oData.Email);
				this.byId("inpgen").setValue(oModel.oData.Gender);
				
				},
					addNewHistory:function(oEvent)
				{
					this.oDialog.open();
				},
				onclosePressed:function(oEvent)
				{
					this.oDialog.close();
				},
			
			});
		
		});
