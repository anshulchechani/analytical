sap.ui.define([
		"zemployee/controller/BaseController",
		"sap/ui/model/json/JSONModel",
		"zemployee/model/formatter",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"sap/m/MessageBox"
	], function (BaseController, JSONModel, formatter, Filter, FilterOperator,MessageBox) {
		"use strict";
        var that;
		return BaseController.extend("zemployee.controller.Worklist", {

			formatter: formatter,

			onInit : function () {
						that=this;
		},
	
		handleNext: function() {
			this.getRouter().navTo("object");
		},
		handleSelection:function(oEvent)
			{
			
			var FirstName= oEvent.getSource().getCells()[0].getText();
			var LastName= oEvent.getSource().getCells()[1].getText();
			var Email= oEvent.getSource().getCells()[2].getText();
			var Gender= oEvent.getSource().getCells()[3].getText();
				var linedata={
				"FirstName":FirstName,
				"LastName":LastName,
				"Email":Email,
				"Gender":Gender
			};
			},
		onEditEmp:function(oEvent)
		{
		var ZEMP_ID= oEvent.getSource().getParent().getParent().getCells()[0].getText();
			var FirstName= oEvent.getSource().getParent().getParent().getCells()[1].getText();
			var LastName= oEvent.getSource().getParent().getParent().getCells()[2].getText();
			var Email= oEvent.getSource().getParent().getParent().getCells()[3].getText();
			var Gender= oEvent.getSource().getParent().getParent().getCells()[4].getText();
			
			var linedata={
				"ZEMP_ID":ZEMP_ID,
				"FirstName":FirstName,
				"LastName":LastName,
				"Email":Email,
            	"Gender":Gender
			};
			var oModel= new JSONModel(linedata);
			sap.ui.getCore().setModel(oModel,"dataModel");
			this.getRouter().navTo("object");
		
		},
		handleDelete:function(oEvent)
		{
			that.EmpId= oEvent.getSource().getParent().getParent().getCells()[0].getText();
			MessageBox.show("Are you Sure You Want To Delete IT ?",{
				title:"question",
				icon:MessageBox.Icon.QUESTION,
				actions:[MessageBox.Action.YES,MessageBox.Action.NO],
				Onclose:function (oAction){
					if(oAction==="YES")
					{
						var oModel=that.getOwnerComponent().getModel();
						var path="/EmployeeDetail("+that.EmpId+")";
						oModel.remove(path,{
							async:true,
							success:function(oData)
							{
								that.getView().getModel().refresh();
							},
							error:function(oError)
							{
								
							}
						});
					}
					if(oAction==="NO")
					{
						//nothing
					}
				}
			});
		}
	});
});
