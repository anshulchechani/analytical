sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("ZSALREGZSALREG.controller.App", {
	
	
	
		 _smartFilterBar: null,
		onInit: function() {

	//	this.byId("tab").getBinding("ZSALES_REGISTER_GSTSet").refresh();
     var smartFilterBar = this.getView().byId("smartFilterBar");
     smartFilterBar.clear();
		// var oComp = this.getOwnerComponent();
		// 	oComp.setModel(this._oModel);
		// 	onAssignedFiltersChanged: function(oEvent) {
		// 	var oStatusText = this.getView().byId();
		// 	if (oStatusText && this._smartFilterBar) {
		// 		var sText = this._smartFilterBar.retrieveFiltersWithValuesAsText();

		// 		oStatusText.setText(sText);
		 	}
	


	});
});