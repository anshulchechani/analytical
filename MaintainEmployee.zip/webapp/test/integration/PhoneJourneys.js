jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"MaintainEmployee/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"MaintainEmployee/test/integration/pages/App",
	"MaintainEmployee/test/integration/pages/Browser",
	"MaintainEmployee/test/integration/pages/Master",
	"MaintainEmployee/test/integration/pages/Detail",
	"MaintainEmployee/test/integration/pages/NotFound"
], function(Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "MaintainEmployee.view."
	});

	sap.ui.require([
		"MaintainEmployee/test/integration/NavigationJourneyPhone",
		"MaintainEmployee/test/integration/NotFoundJourneyPhone",
		"MaintainEmployee/test/integration/BusyJourneyPhone"
	], function() {
		QUnit.start();
	});
});