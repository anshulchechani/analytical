jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 ZUSERDATASet in the list

sap.ui.require([
	"sap/ui/test/Opa5",
	"MaintainEmployee/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"MaintainEmployee/test/integration/pages/App",
	"MaintainEmployee/test/integration/pages/Browser",
	"MaintainEmployee/test/integration/pages/Master",
	"MaintainEmployee/test/integration/pages/Detail",
	"MaintainEmployee/test/integration/pages/Create",
	"MaintainEmployee/test/integration/pages/NotFound"
], function(Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "MaintainEmployee.view."
	});

	sap.ui.require([
		"MaintainEmployee/test/integration/MasterJourney",
		"MaintainEmployee/test/integration/NavigationJourney",
		"MaintainEmployee/test/integration/NotFoundJourney",
		"MaintainEmployee/test/integration/BusyJourney",
		"MaintainEmployee/test/integration/FLPIntegrationJourney"
	], function() {
		QUnit.start();
	});
});